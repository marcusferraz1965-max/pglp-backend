CREATE TABLE pglp_calculos_laudo (
  id_calculo UUID PRIMARY KEY,
  laudo_id UUID NOT NULL,

  template_codigo VARCHAR(50) NOT NULL,
  template_versao VARCHAR(10) NOT NULL,
  template_hash VARCHAR(64) NOT NULL,
  norma VARCHAR(50) NOT NULL,
  parte_norma VARCHAR(20),

  valor_final NUMERIC(15,2) NOT NULL,
  memoria_calculo JSONB NOT NULL,

  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);