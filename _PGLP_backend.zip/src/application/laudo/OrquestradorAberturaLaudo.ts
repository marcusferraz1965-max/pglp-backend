/**
 * SISTEMA: PGLP | MONTE HERMOM
 * ORQUESTRADOR: Abertura Formal do Laudo
 * REGRA: Ordem soberana e nascimento jurídico do laudo
 * VERSÃO: 4.3.1-INTEGRAL
 * DATA: 19/02/2026
 */

import { Injectable, Inject } from '@nestjs/common';
import { randomUUID } from 'crypto';

import {
  FinalidadeLaudo,
  validarFinalidadeLaudo
} from '../../domain/laudo/FinalidadeLaudo';

import { EventoAuditoria } from '../../domain/auditoria/EventoAuditoria';

import { SalvarEstadoAbertura } from './SalvarEstadoAbertura';
import { LaudoPersistenceService } from './LaudoPersistenceService';

/* 🔒 Interface importada SOMENTE como tipo */
import type { AuditoriaRepository } from '../auditoria/AuditoriaRepository';

/* 🔒 Token JÁ EXISTENTE */
import { AUDITORIA_REPOSITORY } from '../tokens';

export interface AberturaLaudoInput {
  objetivo: string;
  finalidade: string;
  esfera: string;
  protocolo: string;
  requerente: string;
  versaoFluxo: string;
}

export interface AberturaLaudoOutput {
  laudoId: string;
}

@Injectable()
export class OrquestradorAberturaLaudo {
  constructor(
    private readonly laudoPersistenceService: LaudoPersistenceService,
    private readonly salvarEstadoAbertura: SalvarEstadoAbertura,

    @Inject(AUDITORIA_REPOSITORY)
    private readonly auditoriaRepository: AuditoriaRepository
  ) {}

  async executar(input: AberturaLaudoInput): Promise<AberturaLaudoOutput> {

    // 1️⃣ Validação de domínio
    const finalidadeValidada: FinalidadeLaudo =
      validarFinalidadeLaudo(input.finalidade);

    // 2️⃣ Identificador soberano
    const laudoId = randomUUID();

    // 3️⃣ Persistência do agregado raiz
    await this.laudoPersistenceService.criar({
      laudoId,
      finalidade: finalidadeValidada,
      versaoFluxo: input.versaoFluxo
    });

    // 4️⃣ Estado inicial do fluxo
    await this.salvarEstadoAbertura.executar({
      laudoId,
      objetivo: input.objetivo,
      finalidade: finalidadeValidada,
      esfera: input.esfera,
      protocolo: input.protocolo,
      requerente: input.requerente,
      status: 'EM_ELABORACAO',
      etapa: 'ABERTURA',
      versaoFluxo: input.versaoFluxo,
      criadoEm: new Date()
    });

    // 5️⃣ Auditoria soberana
    await this.auditoriaRepository.registrarEvento({
      laudoId,
      evento: EventoAuditoria.ABERTURA_LAUDO,
      payload: {
        finalidade: finalidadeValidada,
        status: 'EM_ELABORACAO',
        protocolo: input.protocolo
      },
      ocorridoEm: new Date()
    });

    // 6️⃣ Retorno mínimo
    return { laudoId };
  }
}