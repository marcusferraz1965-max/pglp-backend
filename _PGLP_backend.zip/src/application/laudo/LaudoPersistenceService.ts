/**
 * SISTEMA: PGLP | MONTE HERMOM
 * CASO DE USO: Persistência do Laudo (Agregado Raiz)
 * REGRA: Finalidade imutável após criação
 * VERSÃO: 4.3.0-INTEGRAL
 */

import { FinalidadeLaudo } from '../../domain/laudo/FinalidadeLaudo';

export interface CriarLaudoInput {
  laudoId: string;
  finalidade: FinalidadeLaudo;
  versaoFluxo: string;
}

export interface LaudoPersistenciaModel {
  id: string;
  finalidade: FinalidadeLaudo;
  status: 'EM_ELABORACAO';
  versaoFluxo: string;
  criadoEm: Date;
}

export interface LaudoRepository {
  inserir(laudo: LaudoPersistenciaModel): Promise<void>;
}

export class LaudoPersistenceService {
  constructor(
    private readonly repository: LaudoRepository
  ) {}

  async criar(input: CriarLaudoInput): Promise<void> {
    const laudo: LaudoPersistenciaModel = {
      id: input.laudoId,
      finalidade: input.finalidade,
      status: 'EM_ELABORACAO',
      versaoFluxo: input.versaoFluxo,
      criadoEm: new Date()
    };

    await this.repository.inserir(laudo);
  }
}