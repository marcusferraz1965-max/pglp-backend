/**
 * SISTEMA: PGLP | MONTE HERMOM
 * CASO DE USO: Salvar Estado de Abertura do Laudo
 * REGRA: Persistência pura, sem decisão de domínio
 * VERSÃO: 4.3.0-INTEGRAL
 */

export interface EstadoAberturaInput {
  laudoId: string;
  objetivo: string;
  finalidade: string;
  esfera: string;
  protocolo: string;
  requerente: string;
  status: 'EM_ELABORACAO';
  etapa: 'ABERTURA';
  versaoFluxo: string;
  criadoEm: Date;
}

export interface EstadoAberturaRepository {
  salvar(input: EstadoAberturaInput): Promise<void>;
}

export class SalvarEstadoAbertura {
  constructor(
    private readonly repository: EstadoAberturaRepository
  ) {}

  async executar(input: EstadoAberturaInput): Promise<void> {
    await this.repository.salvar(input);
  }
}