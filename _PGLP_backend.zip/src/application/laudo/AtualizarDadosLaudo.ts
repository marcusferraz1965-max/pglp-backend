import { FinalidadeLaudo } from '../../domain/laudo/FinalidadeLaudo';
import { garantirImutabilidadeFinalidade } from '../../domain/laudo/garantirImutabilidadeFinalidade';

export interface AtualizarLaudoInput {
  laudoId: string;
  finalidadeAtual: FinalidadeLaudo;
  finalidadeProposta: FinalidadeLaudo;
  dados: Record<string, unknown>;
}

export interface AtualizarLaudoRepository {
  atualizar(
    laudoId: string,
    dados: Record<string, unknown>
  ): Promise<void>;
}

export class AtualizarDadosLaudo {
  constructor(
    private readonly repository: AtualizarLaudoRepository
  ) {}

  async executar(input: AtualizarLaudoInput): Promise<void> {
    // 🔒 Blindagem soberana
    garantirImutabilidadeFinalidade(
      input.finalidadeAtual,
      input.finalidadeProposta
    );

    await this.repository.atualizar(input.laudoId, input.dados);
  }
}