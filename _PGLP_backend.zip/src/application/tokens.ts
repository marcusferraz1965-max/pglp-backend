/**
 * SISTEMA: PGLP | MONTE HERMOM
 * MÓDULO RAIZ: AppModule
 * OBJETIVO: Composição final da aplicação
 * VERSÃO: 4.3.1-INTEGRAL
 * DATA: 19/02/2026
 */

import { Module } from '@nestjs/common';

/* =========================
 * CONTROLLERS
 * ========================= */
import { HealthController } from './infrastructure/http/health.controller';
import { LaudosController } from './infrastructure/http/laudos.controller';
import { AssinaturasController } from './infrastructure/http/assinaturas.controller';

/* =========================
 * APPLICATION (USE CASES)
 * ========================= */
import { OrquestradorAberturaLaudo } from './application/laudo/OrquestradorAberturaLaudo';
import { SalvarEstadoAbertura } from './application/laudo/SalvarEstadoAbertura';
import { LaudoPersistenceService } from './application/laudo/LaudoPersistenceService';
import { AssinarLaudo } from './application/assinatura/AssinarLaudo';

/* =========================
 * TOKENS (JÁ EXISTENTES)
 * ========================= */
import {
  LAUDO_REPOSITORY,
  AUDITORIA_REPOSITORY
} from './application/tokens';

/* =========================
 * INFRASTRUCTURE (IMPLEMENTAÇÕES)
 * ========================= */
import { LaudoRepositoryMySQL } from './infrastructure/persistence/laudo.repository.mysql';
import { AuditoriaRepositoryMySQL } from './infrastructure/persistence/auditoria.repository.mysql';

@Module({
  controllers: [
    HealthController,
    LaudosController,
    AssinaturasController
  ],

  providers: [
    /* ===== Use cases ===== */
    OrquestradorAberturaLaudo,
    SalvarEstadoAbertura,
    LaudoPersistenceService,
    AssinarLaudo,

    /* ===== Repositórios ===== */
    {
      provide: LAUDO_REPOSITORY,
      useClass: LaudoRepositoryMySQL
    },
    {
      provide: AUDITORIA_REPOSITORY,
      useClass: AuditoriaRepositoryMySQL
    }
  ]
})
export class AppModule {}