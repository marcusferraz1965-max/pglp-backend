import { randomUUID } from 'crypto';
import { AssinaturaTecnica, Conselho } from '../../domain/assinatura/AssinaturaTecnica';
import { EventoAuditoria } from '../../domain/auditoria/EventoAuditoria';

export interface AssinarLaudoInput {
  laudoId: string;
  hashFinal: string;               // hash do estado final (já calculado)
  profissionalId: string;
  nomeProfissional: string;
  conselho: Conselho;
  registro: string;
  certificado: 'ICP_BRASIL' | 'OUTRO';
  versaoFluxo: string;
}

export interface AssinaturaRepository {
  salvar(assinatura: AssinaturaTecnica): Promise<void>;
}

export interface AuditoriaGateway {
  registrar(input: {
    laudoId: string;
    evento: EventoAuditoria;
    estadoSnapshot: Record<string, unknown>;
    versaoFluxo: string;
  }): Promise<void>;
}

export class AssinarLaudo {
  constructor(
    private readonly assinaturaRepository: AssinaturaRepository,
    private readonly auditoriaGateway: AuditoriaGateway
  ) {}

  async executar(input: AssinarLaudoInput): Promise<void> {
    // Cria assinatura imutável
    const assinatura: AssinaturaTecnica = {
      id: randomUUID(),
      laudoId: input.laudoId,
      profissionalId: input.profissionalId,
      nomeProfissional: input.nomeProfissional,
      conselho: input.conselho,
      registro: input.registro,
      hashAssinado: input.hashFinal,
      certificado: input.certificado,
      assinadoEm: new Date()
    };

    // Persiste assinatura
    await this.assinaturaRepository.salvar(assinatura);

    // Auditoria do ato técnico
    await this.auditoriaGateway.registrar({
      laudoId: input.laudoId,
      evento: EventoAuditoria.ASSINATURA_TECNICA,
      estadoSnapshot: {
        hashAssinado: input.hashFinal,
        conselho: input.conselho,
        registro: input.registro
      },
      versaoFluxo: input.versaoFluxo
    });
  }
}