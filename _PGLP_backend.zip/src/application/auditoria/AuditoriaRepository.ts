/**
 * SISTEMA: PGLP | MONTE HERMOM
 * CAMADA: Application
 * CONTRATO: Auditoria Soberana
 */

export interface AuditoriaRepository {
  registrarEvento(input: {
    laudoId: string;
    evento: string;
    payload?: any;
    ocorridoEm?: Date;
  }): Promise<void>;
}