/**
 * SISTEMA: PGLP | MONTE HERMOM
 * CAMADA: Application
 * CONTRATO: Custódia de Laudo
 */

import { CustodiarLaudoInput } from './CustodiarLaudo';

export interface CustodiaRepository {
  custodiar(
    input: CustodiarLaudoInput
  ): Promise<{
    qrCodeUrl: string;
    localizacao: string;
  }>;
}