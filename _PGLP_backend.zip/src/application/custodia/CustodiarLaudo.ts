import { EventoAuditoria } from '../../domain/auditoria/EventoAuditoria';

export interface CustodiarLaudoInput {
  laudoId: string;
  hashFinal: string;
  urlArquivo: string;
  versaoFluxo: string;
}

export interface CustodiaRepository {
  custodiar(input: CustodiarLaudoInput): Promise<{
    qrCodeUrl: string;
    localizacao: string;
  }>;
}

export interface AuditoriaGateway {
  registrar(input: {
    laudoId: string;
    evento: EventoAuditoria;
    estadoSnapshot: Record<string, unknown>;
    versaoFluxo: string;
  }): Promise<void>;
}

export class CustodiarLaudo {
  constructor(
    private readonly custodiaRepository: CustodiaRepository,
    private readonly auditoriaGateway: AuditoriaGateway
  ) {}

  async executar(input: CustodiarLaudoInput) {
    const resultado = await this.custodiaRepository.custodiar(input);

    await this.auditoriaGateway.registrar({
      laudoId: input.laudoId,
      evento: EventoAuditoria.FECHAMENTO_LAUDO,
      estadoSnapshot: {
        hash: input.hashFinal,
        qrCode: resultado.qrCodeUrl
      },
      versaoFluxo: input.versaoFluxo
    });

    return resultado;
  }
}