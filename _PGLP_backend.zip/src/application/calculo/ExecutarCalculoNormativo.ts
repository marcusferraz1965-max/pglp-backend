/**
 * SISTEMA: PGLP | MONTE HERMOM
 * CASO DE USO: ExecutarCalculoNormativo
 * OBJETIVO:
 * - Executar cálculo normativo (ABNT NBR 14653)
 * - Persistir o resultado vinculado ao laudo
 * - Retornar cálculo auditável
 *
 * OBS:
 * - NÃO contém fórmula
 * - NÃO contém regra matemática
 * - Apenas orquestra core + persistência
 */

import { v4 as uuid } from 'uuid';

// ===== CORE =====
import { CalculoPGLP } from '../../core/calculo/CalculoPGLP';
import { TemplateRepository } from '../../core/templates/TemplateRepository';

// ===== DOMAIN / PERSISTÊNCIA =====
import { CalculoPersistido } from '../../core/calculo/CalculoPersistido';
import { CalculoRepository } from '../../core/calculo/CalculoRepository';

export interface ExecutarCalculoNormativoCommand {
  laudoId: string;
  codigoTemplate: string;
  versao: string;
  valores: Record<string, number>;
}

export class ExecutarCalculoNormativo {
  constructor(
    private readonly calculoEngine: CalculoPGLP,
    private readonly calculoRepository: CalculoRepository
  ) {}

  async execute(
    command: ExecutarCalculoNormativoCommand
  ): Promise<CalculoPersistido> {

    // 1️⃣ Executa cálculo no CORE (normativo)
    const resultado = this.calculoEngine.executar(
      command.codigoTemplate,
      command.versao,
      command.valores
    );

    // 2️⃣ Monta objeto persistido (imutável)
    const calculoPersistido = new CalculoPersistido({
      idCalculo: uuid(),
      laudoId: command.laudoId,

      templateCodigo: resultado.template.codigo,
      templateVersao: resultado.template.versao,
      templateHash: resultado.template.hash,
      norma: resultado.template.norma,
      parteNorma: resultado.template.parteNorma,

      valorFinal: resultado.valorFinal,
      memoriaCalculo: resultado.memoriaCalculo,

      criadoEm: new Date()
    });

    // 3️⃣ Persiste
    await this.calculoRepository.salvar(calculoPersistido);

    // 4️⃣ Retorna cálculo auditável
    return calculoPersistido;
  }
}