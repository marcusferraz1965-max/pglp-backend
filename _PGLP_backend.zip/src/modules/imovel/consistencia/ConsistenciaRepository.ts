import { DivergenciaImovel } from './ValidadorConsistenciaCadastral';

export async function salvarDivergencias(
  imovelId: string,
  divergencias: DivergenciaImovel[],
  db: any
) {
  for (const d of divergencias) {
    await db.query(
      `INSERT INTO tb_imovel_divergencias
       (imovel_id, tipo, campo, valor_informado, valor_oficial, severidade, descricao)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        imovelId,
        d.tipo,
        d.campo,
        d.valorInformado ?? null,
        d.valorOficial ?? null,
        d.severidade,
        d.descricao
      ]
    );
  }
}