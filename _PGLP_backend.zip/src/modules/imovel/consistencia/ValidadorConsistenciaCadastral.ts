export type DivergenciaImovel = {
  tipo: string;
  campo: string;
  valorInformado?: string;
  valorOficial?: string;
  severidade: 'INFO' | 'ALERTA' | 'CRITICO';
  descricao: string;
};

export function validarConsistenciaCadastral(imovel: any): DivergenciaImovel[] {
  const divergencias: DivergenciaImovel[] = [];

  // LOGRADOURO
  if (imovel.localizacao?.logradouro?.origem === 'MANUAL') {
    divergencias.push({
      tipo: 'LOGRADOURO',
      campo: 'localizacao.logradouro',
      valorInformado: imovel.localizacao.logradouro.valor,
      severidade: 'ALERTA',
      descricao: 'Logradouro informado manualmente. Verifique se corresponde à nomenclatura oficial.'
    });
  }

  // MATRÍCULA × CADASTRO MUNICIPAL
  if (
    imovel.identificacao?.matricula?.valor &&
    imovel.identificacao?.codigo_cartografico &&
    imovel.identificacao.matricula.valor !== imovel.identificacao.codigo_cartografico
  ) {
    divergencias.push({
      tipo: 'MATRICULA',
      campo: 'identificacao.matricula',
      valorInformado: imovel.identificacao.matricula.valor,
      valorOficial: imovel.identificacao.codigo_cartografico,
      severidade: 'CRITICO',
      descricao: 'Matrícula diverge do cadastro municipal.'
    });
  }

  // CEP obrigatório
  if (!imovel.localizacao?.cep?.valor) {
    divergencias.push({
      tipo: 'CEP',
      campo: 'localizacao.cep',
      severidade: 'ALERTA',
      descricao: 'CEP não informado. Obrigatório para validação geográfica.'
    });
  }

  return divergencias;
}