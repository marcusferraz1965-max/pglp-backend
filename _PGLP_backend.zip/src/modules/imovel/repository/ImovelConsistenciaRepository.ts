/**
 * PGLP | MONTE HERMOM
 * Repositório de Inconsistências Cadastrais do Imóvel
 */

import { v4 as uuidv4 } from 'uuid';

export type InconsistenciaPersistida = {
  imovel_id: string;
  campo: string;
  origemA: string;
  origemB: string;
  valorA: string | null;
  valorB: string | null;
  tipo: string;
  severidade: string;
  observacao: string;
};

export class ImovelConsistenciaRepository {

  static async salvar(imovelId: string, inconsistencias: InconsistenciaPersistida[]) {
    for (const inc of inconsistencias) {
      await db.query(
        `
        INSERT INTO tb_imovel_inconsistencias (
          id, imovel_id, campo,
          origem_a, origem_b,
          valor_a, valor_b,
          tipo, severidade, observacao
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)
        `,
        [
          uuidv4(),
          imovelId,
          inc.campo,
          inc.origemA,
          inc.origemB,
          inc.valorA,
          inc.valorB,
          inc.tipo,
          inc.severidade,
          inc.observacao
        ]
      );
    }
  }

  static async listarPendentes(imovelId: string) {
    const { rows } = await db.query(
      `
      SELECT *
      FROM tb_imovel_inconsistencias
      WHERE imovel_id = $1
        AND resolvida = FALSE
      ORDER BY severidade DESC, criado_em ASC
      `,
      [imovelId]
    );
    return rows;
  }

  static async resolver(id: string, usuarioId: string, observacao?: string) {
    await db.query(
      `
      UPDATE tb_imovel_inconsistencias
      SET
        resolvida = TRUE,
        resolvida_por = $2,
        resolvida_em = NOW(),
        observacao_resolucao = $3
      WHERE id = $1
      `,
      [id, usuarioId, observacao || null]
    );
  }
}