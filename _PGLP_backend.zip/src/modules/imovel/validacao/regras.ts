export function compararValores(
  campo: string,
  valorA: string | null,
  valorB: string | null,
  origemA: string,
  origemB: string
) {
  if (!valorA || !valorB) return null;

  if (valorA !== valorB) {
    return {
      campo,
      origemA,
      origemB,
      valorA,
      valorB,
      tipo: 'ALERTA',
      mensagem: `Divergência detectada no campo ${campo}`
    };
  }

  return null;
}