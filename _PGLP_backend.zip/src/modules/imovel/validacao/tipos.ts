export type InconsistenciaCadastral = {
  campo: string;
  origemA: string;
  origemB: string;
  valorA: string | null;
  valorB: string | null;
  tipo: 'ERRO' | 'ALERTA';
  mensagem: string;
};

export type ResultadoConsistenciaCadastral = {
  valido: boolean;
  inconsistencias: InconsistenciaCadastral[];
};