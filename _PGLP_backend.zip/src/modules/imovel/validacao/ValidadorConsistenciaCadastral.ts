/**
 * PGLP - MONTE HERMOM
 * =========================================================
 * ARQUIVO: validadorConsistenciaCadastral.ts
 * CAMADA: Backend | Módulo Imóvel | Consistência
 * =========================================================
 * FINALIDADE:
 * - Confrontar dados cadastrais do imóvel
 * - Detectar divergências entre fontes oficiais
 * - Produzir inconsistências auditáveis (não corretivas)
 *
 * PRINCÍPIOS:
 * - Document-first
 * - Não corrige
 * - Não decide
 * - Não bloqueia
 * =========================================================
 */

export type InconsistenciaCadastral = {
  campo: string;
  origemA: string;
  origemB: string;
  valorA: string | null;
  valorB: string | null;
  tipo: 'DIVERGENCIA' | 'AUSENCIA';
  severidade: 'INFO' | 'ALERTA';
  observacao: string;
};

export type ResultadoConsistenciaCadastral = {
  consistente: boolean;
  inconsistencias: InconsistenciaCadastral[];
};

type FonteCadastral = {
  origem: string; // MATRÍCULA | CADASTRO_MUNICIPAL | OCR | MANUAL
  dados: Record<string, string | null>;
};

/**
 * Helper de comparação segura
 */
function comparar(
  campo: string,
  a: FonteCadastral,
  b: FonteCadastral,
  severidade: 'INFO' | 'ALERTA'
): InconsistenciaCadastral | null {

  const valorA = a.dados[campo] ?? null;
  const valorB = b.dados[campo] ?? null;

  if (!valorA && !valorB) {
    return null;
  }

  if (!valorA || !valorB) {
    return {
      campo,
      origemA: a.origem,
      origemB: b.origem,
      valorA,
      valorB,
      tipo: 'AUSENCIA',
      severidade,
      observacao: `Campo presente apenas em uma das fontes.`
    };
  }

  if (valorA !== valorB) {
    return {
      campo,
      origemA: a.origem,
      origemB: b.origem,
      valorA,
      valorB,
      tipo: 'DIVERGENCIA',
      severidade,
      observacao: `Valores divergentes entre ${a.origem} e ${b.origem}.`
    };
  }

  return null;
}

/**
 * VALIDADOR PRINCIPAL
 */
export function validarConsistenciaCadastralImovel(
  fontes: FonteCadastral[]
): ResultadoConsistenciaCadastral {

  const inconsistencias: InconsistenciaCadastral[] = [];

  const camposCriticos = [
    'logradouro',
    'bairro',
    'cidade',
    'uf',
    'cep',
    'matricula',
    'codigo_cartografico'
  ];

  for (let i = 0; i < fontes.length; i++) {
    for (let j = i + 1; j < fontes.length; j++) {

      const fonteA = fontes[i];
      const fonteB = fontes[j];

      for (const campo of camposCriticos) {
        const inc = comparar(
          campo,
          fonteA,
          fonteB,
          campo === 'matricula' || campo === 'codigo_cartografico'
            ? 'ALERTA'
            : 'INFO'
        );

        if (inc) inconsistencias.push(inc);
      }
    }
  }

  return {
    consistente: inconsistencias.length === 0,
    inconsistencias
  };
}