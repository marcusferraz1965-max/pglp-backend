/**
 * PGLP | MONTE HERMOM
 * =========================================================
 * AVALIADOR SOBERANO DE STATUS DO IMÓVEL
 * =========================================================
 * STATUS é derivado do estado do imóvel,
 * nunca definido manualmente.
 */

export function avaliarStatusImovel({
  etapasConcluidas,
  inconsistenciasPendentes,
  validacaoConcluida
}: {
  etapasConcluidas: string[];
  inconsistenciasPendentes: number;
  validacaoConcluida: boolean;
}): 'CRIADO' | 'EM_PREENCHIMENTO' | 'EM_VALIDACAO' | 'EM_ALERTA' | 'VALIDADO' {

  // Nenhuma etapa ainda
  if (!etapasConcluidas || etapasConcluidas.length === 0) {
    return 'CRIADO';
  }

  // Etapas em andamento
  if (!validacaoConcluida) {
    return 'EM_PREENCHIMENTO';
  }

  // Validação feita, mas há inconsistências
  if (inconsistenciasPendentes > 0) {
    return 'EM_ALERTA';
  }

  // Tudo validado e consistente
  return 'VALIDADO';
}