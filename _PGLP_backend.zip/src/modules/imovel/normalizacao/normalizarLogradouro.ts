/**
 * PGLP | MONTE HERMOM
 * =========================================================
 * ARQUIVO: normalizarLogradouro.ts
 * CAMADA: Backend | Normalização Técnica
 * =========================================================
 * FINALIDADE:
 * - Normalizar logradouro conforme tb_logradouros
 * - Eliminar abreviações
 * - Garantir padrão judicial / NBR 14653
 * =========================================================
 * REGRA:
 * ❌ Não inventa tipo
 * ❌ Não corrige semanticamente
 * ✅ Apenas reconhece e normaliza
 * =========================================================
 */

export type LogradouroNormalizadoBackend = {
  tipo: string | null;
  nome: string | null;
  completo: string | null;
  valido: boolean;
  alerta?: string;
};

/**
 * Espelho CANÔNICO da tb_logradouros
 * (pode futuramente vir do banco / cache)
 */
const MAPA_LOGRADOUROS: Record<string, string> = {
  RUA: 'RUA',
  R: 'RUA',

  AVENIDA: 'AVENIDA',
  AV: 'AVENIDA',

  TRAVESSA: 'TRAVESSA',
  TRAV: 'TRAVESSA',

  ALAMEDA: 'ALAMEDA',

  PRAÇA: 'PRAÇA',
  PRACA: 'PRAÇA',

  LARGO: 'LARGO',
  VIELA: 'VIELA',
  BECO: 'BECO',

  RODOVIA: 'RODOVIA',
  BR: 'RODOVIA',

  ESTRADA: 'ESTRADA',
  CAMINHO: 'CAMINHO',

  FAZENDA: 'FAZENDA',
  SITIO: 'SÍTIO',
  SÍTIO: 'SÍTIO',
  CHACARA: 'CHÁCARA',
  CHÁCARA: 'CHÁCARA',

  CONDOMINIO: 'CONDOMÍNIO',
  CONDOMÍNIO: 'CONDOMÍNIO',

  LOTEAMENTO: 'LOTEAMENTO',
  VILA: 'VILA',
  JARDIM: 'JARDIM',
  PARQUE: 'PARQUE',

  QUADRA: 'QUADRA',
  SETOR: 'SETOR',

  ESCADARIA: 'ESCADARIA',
  LADEIRA: 'LADEIRA',
  RAMPA: 'RAMPA',
  MARGINAL: 'MARGINAL'
};

/**
 * NORMALIZADOR SOBERANO – BACKEND
 */
export function normalizarLogradouroBackend(
  entrada?: string | null
): LogradouroNormalizadoBackend {

  if (!entrada || entrada.trim().length === 0) {
    return {
      tipo: null,
      nome: null,
      completo: null,
      valido: false,
      alerta: 'Logradouro não informado.'
    };
  }

  const texto = entrada
    .trim()
    .toUpperCase()
    .replace(/\s+/g, ' ');

  const partes = texto.split(' ');
  const primeira = partes[0];

  const tipo = MAPA_LOGRADOUROS[primeira];

  if (!tipo) {
    return {
      tipo: null,
      nome: texto,
      completo: texto,
      valido: false,
      alerta: 'Tipo de logradouro não reconhecido (padrão judicial).'
    };
  }

  const nome = partes.slice(1).join(' ').trim();

  if (!nome) {
    return {
      tipo,
      nome: null,
      completo: tipo,
      valido: false,
      alerta: 'Nome do logradouro ausente.'
    };
  }

  return {
    tipo,
    nome,
    completo: `${tipo} ${nome}`,
    valido: true
  };
}