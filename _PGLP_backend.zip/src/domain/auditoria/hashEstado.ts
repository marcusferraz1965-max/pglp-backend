import { createHash } from 'crypto';

/**
 * Gera hash SHA-256 a partir de JSON canônico (ordem estável).
 */
export function gerarHashEstado(payload: Record<string, unknown>): string {
  const jsonCanonico = JSON.stringify(
    payload,
    Object.keys(payload).sort()
  );
  return createHash('sha256').update(jsonCanonico).digest('hex');
}