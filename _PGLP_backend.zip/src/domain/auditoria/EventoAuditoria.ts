/**
 * DOMÍNIO: Eventos de Auditoria
 * REGRA: Conjunto fechado e versionável
 */
export enum EventoAuditoria {
  ABERTURA_LAUDO = 'ABERTURA_LAUDO',
  ALTERACAO_DADOS = 'ALTERACAO_DADOS',
  FECHAMENTO_LAUDO = 'FECHAMENTO_LAUDO',
  ASSINATURA_TECNICA = 'ASSINATURA_TECNICA'
}