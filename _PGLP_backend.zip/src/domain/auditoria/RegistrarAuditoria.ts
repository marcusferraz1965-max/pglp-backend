import { EventoAuditoria } from '../../domain/auditoria/EventoAuditoria';
import { gerarHashEstado } from '../../domain/auditoria/hashEstado';

export interface RegistrarAuditoriaInput {
  laudoId: string;
  evento: EventoAuditoria;
  estadoSnapshot: Record<string, unknown>;
  usuarioId?: string;
  versaoFluxo: string;
}

export interface AuditoriaRepository {
  registrar(input: {
    laudoId: string;
    evento: EventoAuditoria;
    hashEstado: string;
    usuarioId?: string;
    versaoFluxo: string;
    ocorridoEm: Date;
  }): Promise<void>;
}

export class RegistrarAuditoria {
  constructor(
    private readonly repository: AuditoriaRepository
  ) {}

  async executar(input: RegistrarAuditoriaInput): Promise<void> {
    const hashEstado = gerarHashEstado(input.estadoSnapshot);

    await this.repository.registrar({
      laudoId: input.laudoId,
      evento: input.evento,
      hashEstado,
      usuarioId: input.usuarioId,
      versaoFluxo: input.versaoFluxo,
      ocorridoEm: new Date()
    });
  }
}