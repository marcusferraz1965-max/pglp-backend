// src/domain/calculo/dto/executar-calculo.dto.ts

import { IsString, IsObject } from 'class-validator';

export class ExecutarCalculoDto {
  @IsString()
  laudoId!: string;

  @IsString()
  codigoTemplate!: string;

  @IsString()
  versao!: string;

  @IsObject()
  valores!: Record<string, number>;
}