// src/domain/calculo/calculo.service.ts

import { Injectable, OnModuleInit } from '@nestjs/common';
import { v4 as uuid } from 'uuid';

// ===== CORE (NORMATIVO) =====
import { TemplateRepository } from '../../../core/templates/TemplateRepository';
import { loadTemplatesFromSeed } from '../../../core/templates/loadTemplatesFromSeed';
import { CalculoPGLP } from '../../../core/calculo/CalculoPGLP';

import { CalculoPersistido } from '../../../core/calculo/CalculoPersistido';
import { CalculoRepository } from '../../../core/calculo/CalculoRepository';
import { CalculoRepositoryMemory } from '../../../core/calculo/CalculoRepositoryMemory';

// ===== ORQUESTRADOR =====
import { OrquestradorLaudo } from '../../../core/orquestrador/OrquestradorLaudo';

@Injectable()
export class CalculoService implements OnModuleInit {

  private templateRepo!: TemplateRepository;
  private calculoEngine!: CalculoPGLP;
  private calculoRepo!: CalculoRepository;

  // -----------------------------------
  // Bootstrap do domínio de cálculo
  // -----------------------------------
  onModuleInit() {
    // 1️⃣ Templates normativos
    this.templateRepo = new TemplateRepository();

    loadTemplatesFromSeed(
      this.templateRepo,
      './seed/templates_oficiais.json'
    );

    // 2️⃣ Engine soberana de cálculo
    this.calculoEngine = new CalculoPGLP(this.templateRepo);

    // 3️⃣ Repositório de persistência
    this.calculoRepo = new CalculoRepositoryMemory();
  }

  // ===================================
  // Executa e persiste cálculo do laudo
  // ===================================
  async executarEGuardarCalculo(params: {
    laudoId: string;
    codigoTemplate: string;
    versao: string;
    valores: Record<string, number>;
  }): Promise<CalculoPersistido> {

    // 🔒 execução normativa
    const resultado = this.calculoEngine.executar(
      params.codigoTemplate,
      params.versao,
      params.valores
    );

    const calculoPersistido = new CalculoPersistido({
      idCalculo: uuid(),
      laudoId: params.laudoId,

      templateCodigo: resultado.template.codigo,
      templateVersao: resultado.template.versao,
      templateHash: resultado.template.hash,
      norma: resultado.template.norma,
      parteNorma: resultado.template.parteNorma,

      valorFinal: resultado.valorFinal,
      memoriaCalculo: resultado.memoriaCalculo,

      criadoEm: new Date()
    });

    await this.calculoRepo.salvar(calculoPersistido);

    return calculoPersistido;
  }

  // ===================================
  // Lista cálculos vinculados ao laudo
  // ===================================
  async listarCalculosDoLaudo(
    laudoId: string
  ): Promise<CalculoPersistido[]> {
    return this.calculoRepo.listarPorLaudo(laudoId);
  }

  // ===================================
  // Validação antes de assinatura
  // ===================================
  async validarLaudoParaAssinatura(
    laudoId: string
  ): Promise<void> {

    const calculos = await this.calculoRepo.listarPorLaudo(laudoId);

    OrquestradorLaudo.antesDeAssinarLaudo(
      calculos.map(c => ({
        template: {
          codigo: c.templateCodigo,
          versao: c.templateVersao,
          norma: c.norma,
          hash: c.templateHash
        },
        valorFinal: c.valorFinal,
        memoriaCalculo: c.memoriaCalculo
      }))
    );
  }
}