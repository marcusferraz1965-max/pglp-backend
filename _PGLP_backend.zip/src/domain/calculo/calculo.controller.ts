// src/domain/calculo/calculo.controller.ts

import {
  Controller,
  Post,
  Body,
  HttpException,
  HttpStatus
} from '@nestjs/common';

import { CalculoService } from './calculo.service';
import { ExecutarCalculoDto } from './dto/executar-calculo.dto';

@Controller('calculos')
export class CalculoController {

  constructor(
    private readonly calculoService: CalculoService
  ) {}

  /**
   * Executa e persiste um cálculo normativo
   * conforme ABNT NBR 14.653
   */
  @Post('executar')
  async executar(@Body() dto: ExecutarCalculoDto) {
    try {
      return await this.calculoService.executarEGuardarCalculo({
        laudoId: dto.laudoId,
        codigoTemplate: dto.codigoTemplate,
        versao: dto.versao,
        valores: dto.valores
      });
    } catch (err: any) {
      throw new HttpException(
        {
          message: err.message,
          origem: 'PGLP_CALCULO'
        },
        HttpStatus.BAD_REQUEST
      );
    }
  }
}