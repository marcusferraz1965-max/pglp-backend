/**
 * DOMÍNIO: Assinatura Técnica do Laudo
 * REGRA: Assina-se o HASH do estado final, nunca o PDF
 */

export type Conselho = 'CREA' | 'CAU';

export interface AssinaturaTecnica {
  id: string;
  laudoId: string;
  profissionalId: string;
  nomeProfissional: string;
  conselho: Conselho;
  registro: string;
  hashAssinado: string;
  certificado: 'ICP_BRASIL' | 'OUTRO';
  assinadoEm: Date;
}