// src/domain/laudo/laudo.service.ts

import { Injectable } from '@nestjs/common';

// domínio de cálculo
import { CalculoService } from '../calculo/calculo.service';

@Injectable()
export class LaudoService {

  constructor(
    private readonly calculoService: CalculoService
  ) {}

  /**
   * Assina o laudo somente se estiver
   * conforme ABNT NBR 14.653
   */
  async assinarLaudo(
    laudoId: string,
    dados: {
      responsavelTecnicoId: string;
      registroProfissional: string;
    }
  ) {

    // 🔒 bloqueio normativo
    await this.calculoService.validarLaudoParaAssinatura(laudoId);

    // ✍️ assinatura (persistência real depois)
    return {
      laudoId,
      responsavelTecnicoId: dados.responsavelTecnicoId,
      registroProfissional: dados.registroProfissional,
      assinadoEm: new Date(),
      status: 'ASSINADO'
    };
  }
}