/**
 * ERRO DE DOMÍNIO: Violação de Imutabilidade
 */
export class FinalidadeImutavelError extends Error {
  constructor() {
    super('A finalidade do laudo é imutável após a abertura.');
  }
}