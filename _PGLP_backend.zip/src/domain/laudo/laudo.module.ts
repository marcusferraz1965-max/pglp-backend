// src/domain/laudo/laudo.module.ts

import { Module } from '@nestjs/common';

import { LaudoController } from './laudo.controller';
import { LaudoService } from './laudo.service';
import { CalculoModule } from '../calculo/calculo.module';

@Module({
  imports: [CalculoModule],
  controllers: [LaudoController],
  providers: [LaudoService]
})
export class LaudoModule {}