import { FinalidadeImutavelError } from './FinalidadeImutavelError';
import { FinalidadeLaudo } from './FinalidadeLaudo';

/**
 * Garante que a finalidade não seja alterada após definida.
 */
export function garantirImutabilidadeFinalidade(
  finalidadeAtual: FinalidadeLaudo,
  novaFinalidade: FinalidadeLaudo
): void {
  if (finalidadeAtual !== novaFinalidade) {
    throw new FinalidadeImutavelError();
  }
}