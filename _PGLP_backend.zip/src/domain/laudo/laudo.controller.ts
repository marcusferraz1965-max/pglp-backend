// src/domain/laudo/laudo.controller.ts

import {
  Controller,
  Post,
  Param,
  Body,
  HttpException,
  HttpStatus
} from '@nestjs/common';

import { LaudoService } from './laudo.service';
import { AssinarLaudoDto } from './dto/assinar-laudo.dto';

@Controller('laudos')
export class LaudoController {

  constructor(
    private readonly laudoService: LaudoService
  ) {}

  /**
   * Assinatura oficial do laudo técnico
   */
  @Post(':id/assinar')
  async assinar(
    @Param('id') laudoId: string,
    @Body() dto: AssinarLaudoDto
  ) {
    try {
      return await this.laudoService.assinarLaudo(
        laudoId,
        dto
      );
    } catch (err: any) {
      throw new HttpException(
        {
          message: err.message,
          origem: 'PGLP_LAUDO'
        },
        HttpStatus.BAD_REQUEST
      );
    }
  }
}