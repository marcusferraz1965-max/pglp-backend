// src/domain/laudo/dto/assinar-laudo.dto.ts

import { IsString } from 'class-validator';

export class AssinarLaudoDto {
  @IsString()
  responsavelTecnicoId!: string;

  @IsString()
  registroProfissional!: string; // CREA / CAU
}