/**
 * SISTEMA: PGLP | MONTE HERMOM
 * DOMÍNIO: Finalidade do Laudo
 * REGRA: Domínio fechado, imutável após abertura
 * VERSÃO: 4.3.0-INTEGRAL
 */

export enum FinalidadeLaudo {
  JUDICIAL = 'JUDICIAL',
  BANCARIA = 'BANCARIA',
  ADMINISTRATIVA = 'ADMINISTRATIVA'
}

/**
 * Validação soberana de finalidade.
 * Usada antes de qualquer persistência.
 */
export function validarFinalidadeLaudo(finalidade: string): FinalidadeLaudo {
  if (!Object.values(FinalidadeLaudo).includes(finalidade as FinalidadeLaudo)) {
    throw new Error(`Finalidade inválida: ${finalidade}`);
  }

  return finalidade as FinalidadeLaudo;
}