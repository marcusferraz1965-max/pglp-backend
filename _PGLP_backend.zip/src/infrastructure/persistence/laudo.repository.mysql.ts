/**
 * SISTEMA: PGLP | MONTE HERMOM
 * CAMADA: Infrastructure
 * MÓDULO: Persistência MySQL – Laudo
 * VERSÃO: 1.0.0
 * DATA: 19/02/2026
 *
 * OBJETIVO:
 * Implementar o contrato LaudoRepository usando MySQL
 */

import { mysqlPool } from '../db/mysql.connection';
import {
  LaudoRepository,
  LaudoPersistenciaModel
} from '../../application/laudo/LaudoPersistenceService';

export class LaudoRepositoryMySQL implements LaudoRepository {
  async inserir(laudo: LaudoPersistenciaModel): Promise<void> {
    const sql = `
      INSERT INTO tb_laudos
        (id, finalidade, status, versao_fluxo, criado_em)
      VALUES
        (?, ?, ?, ?, ?)
    `;

    await mysqlPool.execute(sql, [
      laudo.id,
      laudo.finalidade,
      laudo.status,
      laudo.versaoFluxo,
      laudo.criadoEm
    ]);
  }
}