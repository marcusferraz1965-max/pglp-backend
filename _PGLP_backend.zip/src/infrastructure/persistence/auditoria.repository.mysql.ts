/**
 * SISTEMA: PGLP | MONTE HERMOM
 * CAMADA: Infrastructure
 * IMPLEMENTAÇÃO: AuditoriaRepository (MySQL)
 */

import { mysqlPool } from '../db/mysql.connection';
import { AuditoriaRepository } from '../../application/auditoria/AuditoriaRepository';
import { EventoAuditoria } from '../../domain/auditoria/EventoAuditoria';

export class AuditoriaRepositoryMySQL implements AuditoriaRepository {

  async registrarEvento(input: {
    laudoId: string;
    evento: EventoAuditoria;
    hashEstado: string;
    ocorridoEm?: Date;
  }): Promise<void> {

    const sql = `
      INSERT INTO tb_laudo_eventos
        (laudo_id, evento, hash_estado, criado_em)
      VALUES
        (?, ?, ?, ?)
    `;

    await mysqlPool.execute(sql, [
      input.laudoId,
      input.evento,
      input.hashEstado,
      input.ocorridoEm ?? new Date()
    ]);
  }
}