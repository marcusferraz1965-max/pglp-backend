/**
 * SISTEMA: PGLP | MONTE HERMOM
 * CAMADA: Infrastructure
 * IMPLEMENTAÇÃO: AuditoriaRepository
 *
 * RESPONSABILIDADE:
 * - Persistir eventos de auditoria
 * - Cumprir o contrato definido em application
 * - Não conter regra de negócio
 */

import { AuditoriaRepository } from '../../application/auditoria/AuditoriaRepository';
import { EventoAuditoria } from '../../domain/auditoria/EventoAuditoria';

export class AuditoriaRepositoryImpl implements AuditoriaRepository {

  async registrarEvento(input: {
    laudoId: string;
    evento: EventoAuditoria;
    payload?: any;
    ocorridoEm?: Date;
  }): Promise<void> {

    const eventoPersistido = {
      laudoId: input.laudoId,
      evento: input.evento,
      payload: input.payload ?? null,
      ocorridoEm: input.ocorridoEm ?? new Date()
    };

    // 🔒 Implementação real (DB / ORM) entra aqui
    // Exemplo provisório:
    console.log('[AUDITORIA] Evento registrado:', eventoPersistido);
  }
}