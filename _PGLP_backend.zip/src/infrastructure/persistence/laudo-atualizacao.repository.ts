import { AtualizarLaudoRepository } from '../../application/laudo/AtualizarDadosLaudo';

export class AtualizarLaudoRepositoryImpl
  implements AtualizarLaudoRepository {

  async atualizar(
    laudoId: string,
    dados: Record<string, unknown>
  ): Promise<void> {
    // ORM/DB aqui
    console.log('[DB] Atualizando Laudo:', laudoId, dados);
  }
}