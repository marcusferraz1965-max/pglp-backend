/**
 * SISTEMA: PGLP | MONTE HERMOM
 * REPOSITORY: Estado de Abertura do Laudo
 * REGRA: Persistência de processo (não é domínio)
 */

import {
  EstadoAberturaRepository,
  EstadoAberturaInput
} from '../../application/laudo/SalvarEstadoAbertura';

export class EstadoAberturaRepositoryImpl
  implements EstadoAberturaRepository {

  async salvar(input: EstadoAberturaInput): Promise<void> {
    /**
     * IMPLEMENTAÇÃO REAL ENTRA AQUI
     * Exemplo futuro:
     * await this.orm.estadosAbertura.create({ data: input })
     */

    console.log('[DB] Salvando Estado de Abertura:', input);
  }
}