import { mysqlPool } from '../db/mysql.connection';
import {
  EstadoAberturaRepository,
  EstadoAberturaInput
} from '../../application/laudo/SalvarEstadoAbertura';

export class LaudoEventosRepositoryMySQL
  implements EstadoAberturaRepository {

  async salvar(input: EstadoAberturaInput): Promise<void> {
    const sql = `
      INSERT INTO tb_laudo_eventos
        (laudo_id, evento, etapa, status, protocolo, criado_em)
      VALUES
        (?, ?, ?, ?, ?, ?)
    `;

    await mysqlPool.execute(sql, [
      input.laudoId,
      'ABERTURA_LAUDO',
      input.etapa,
      input.status,
      input.protocolo,
      input.criadoEm
    ]);
  }
}