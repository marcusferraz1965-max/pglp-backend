/**
 * SISTEMA: PGLP | MONTE HERMOM
 * REPOSITORY: Laudo (Infraestrutura)
 * REGRA: Persistência pura, sem regra de negócio
 */

import { LaudoRepository, LaudoPersistenciaModel } 
  from '../../application/laudo/LaudoPersistenceService';

export class LaudoRepositoryImpl implements LaudoRepository {

  async inserir(laudo: LaudoPersistenciaModel): Promise<void> {
    /**
     * IMPLEMENTAÇÃO REAL ENTRA AQUI
     * Exemplo futuro:
     * await this.orm.laudos.create({ data: laudo })
     */

    console.log('[DB] Inserindo Laudo:', laudo);
  }
}