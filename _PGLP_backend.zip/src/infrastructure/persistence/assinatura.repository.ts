import { AssinaturaRepository } from '../../application/assinatura/AssinarLaudo';
import { AssinaturaTecnica } from '../../domain/assinatura/AssinaturaTecnica';

export class AssinaturaRepositoryImpl implements AssinaturaRepository {
  async salvar(assinatura: AssinaturaTecnica): Promise<void> {
    // ORM/DB real entra aqui
    console.log('[DB] Assinatura Técnica salva:', assinatura);
  }
}