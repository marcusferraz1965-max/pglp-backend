/**
 * SISTEMA: PGLP | MONTE HERMOM
 * CONTROLLER: Health Check
 * REGRA: Sanidade da aplicação (infra / deploy / uptime)
 */

import { Controller, Get } from '@nestjs/common';

@Controller('health')
export class HealthController {

  @Get()
  check() {
    return {
      status: 'ok',
      service: 'PGLP Backend',
      timestamp: new Date().toISOString()
    };
  }
}