import {
  Body,
  Controller,
  HttpCode,
  HttpStatus,
  Post
} from '@nestjs/common';

import { AssinarLaudo } from '../../application/assinatura/AssinarLaudo';

@Controller('laudos')
export class AssinaturasController {
  constructor(
    private readonly assinarLaudo: AssinarLaudo
  ) {}

  @Post(':id/assinar')
  @HttpCode(HttpStatus.NO_CONTENT)
  async assinar(
    @Body() body: any
  ) {
    await this.assinarLaudo.executar({
      laudoId: body.laudoId,
      hashFinal: body.hashFinal,
      profissionalId: body.profissionalId,
      nomeProfissional: body.nomeProfissional,
      conselho: body.conselho,
      registro: body.registro,
      certificado: body.certificado,
      versaoFluxo: body.versaoFluxo
    });
  }
}