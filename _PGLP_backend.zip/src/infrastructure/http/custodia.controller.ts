import { Body, Controller, HttpCode, HttpStatus, Post } from '@nestjs/common';
import { CustodiarLaudo } from '../../application/custodia/CustodiarLaudo';

@Controller('laudos')
export class CustodiaController {
  constructor(
    private readonly custodiarLaudo: CustodiarLaudo
  ) {}

  @Post(':id/custodiar')
  @HttpCode(HttpStatus.CREATED)
  async custodiar(@Body() body: any) {
    return this.custodiarLaudo.executar(body);
  }
}