import {
  Body,
  Controller,
  HttpCode,
  HttpStatus,
  Post,
  Patch,
  Param,
  BadRequestException
} from '@nestjs/common';

import { OrquestradorAberturaLaudo } from '../../application/laudo/OrquestradorAberturaLaudo';
import { AtualizarDadosLaudo } from '../../application/laudo/AtualizarDadosLaudo';
import { FinalidadeImutavelError } from '../../domain/laudo/FinalidadeImutavelError';

// ✅ NOVO USE CASE (ADIÇÃO)
import { ExecutarCalculoNormativo } from '../../application/calculo/ExecutarCalculoNormativo';

@Controller('laudos')
export class LaudosController {
  constructor(
    private readonly orquestradorAberturaLaudo: OrquestradorAberturaLaudo,
    private readonly atualizarDadosLaudo: AtualizarDadosLaudo,
    // ✅ INJETADO SEM ALTERAR OS EXISTENTES
    private readonly executarCalculoNormativo: ExecutarCalculoNormativo
  ) {}

  // =========================
  // ABERTURA DO LAUDO
  // =========================
  @Post('abrir')
  @HttpCode(HttpStatus.CREATED)
  async abrirLaudo(@Body() body: any) {
    const resultado = await this.orquestradorAberturaLaudo.executar({
      objetivo: body.objetivo,
      finalidade: body.finalidade,
      esfera: body.esfera,
      protocolo: body.protocolo,
      requerente: body.requerente,
      versaoFluxo: body.versaoFluxo
    });

    return {
      laudoId: resultado.laudoId
    };
  }

  // =========================
  // ATUALIZAÇÃO (IMUTÁVEL)
  // =========================
  @Patch(':id')
  async atualizarLaudo(
    @Param('id') id: string,
    @Body() body: any
  ) {
    try {
      await this.atualizarDadosLaudo.executar({
        laudoId: id,
        finalidadeAtual: body.finalidadeAtual,
        finalidadeProposta: body.finalidadeProposta,
        dados: body.dados
      });

      return { sucesso: true };
    } catch (e) {
      if (e instanceof FinalidadeImutavelError) {
        throw new BadRequestException(e.message);
      }
      throw e;
    }
  }

  // =========================
  // CÁLCULO NORMATIVO (NOVO)
  // =========================
  @Post(':id/calculos')
  async executarCalculo(
    @Param('id') laudoId: string,
    @Body() body: {
      codigoTemplate: string;
      versao: string;
      valores: Record<string, number>;
    }
  ) {
    try {
      return await this.executarCalculoNormativo.execute({
        laudoId,
        codigoTemplate: body.codigoTemplate,
        versao: body.versao,
        valores: body.valores
      });
    } catch (e: any) {
      throw new BadRequestException(e.message);
    }
  }
}