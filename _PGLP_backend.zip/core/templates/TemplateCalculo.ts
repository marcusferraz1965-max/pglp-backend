// /core/templates/TemplateCalculo.ts

export type TemplateStatus =
  | 'RASCUNHO'
  | 'EM_REVISAO'
  | 'APROVADO'
  | 'ATIVO'
  | 'INATIVO';

export interface VariavelTemplate {
  descricao: string;
  unidade: string;
}

export interface FormulaDesenhada {
  tipo: 'FRAC' | 'MULT' | 'SUB';
  estrutura?: string;
  numerador?: string[];
  denominador?: string[];
}

export class TemplateCalculo {
  readonly idTemplate: string;
  readonly codigo: string;
  readonly nome: string;
  readonly descricao: string;

  readonly norma: string;
  readonly parteNorma?: string;

  readonly formulaSimbolica: string;
  readonly formulaDesenhada: FormulaDesenhada;
  readonly variaveis: Record<string, VariavelTemplate>;

  readonly legendaPadrao: boolean;
  readonly memoriaPadrao: boolean;

  readonly usoPermitido: 'LAUDO' | 'INTERNO';
  readonly financeiro: boolean;

  readonly versao: string;
  readonly hashTemplate: string;
  readonly status: TemplateStatus;

  constructor(props: TemplateCalculo) {
    if (props.status === 'ATIVO' && props.financeiro === true) {
      throw new Error('Template financeiro não pode ser ATIVO para LAUDO');
    }

    Object.assign(this, props);
  }

  isAtivo(): boolean {
    return this.status === 'ATIVO';
  }
}