// /core/templates/TemplateRepository.ts

import { TemplateCalculo } from './TemplateCalculo';

export class TemplateRepository {
  private templates: Map<string, TemplateCalculo> = new Map();

  add(template: TemplateCalculo): void {
    const key = this.buildKey(template.codigo, template.versao);

    if (this.templates.has(key)) {
      throw new Error(`Template já existente: ${template.codigo} v${template.versao}`);
    }

    this.templates.set(key, template);
  }

  get(codigo: string, versao: string): TemplateCalculo {
    const key = this.buildKey(codigo, versao);
    const template = this.templates.get(key);

    if (!template) {
      throw new Error(`Template não encontrado: ${codigo} v${versao}`);
    }

    if (!template.isAtivo()) {
      throw new Error(`Template não está ativo: ${codigo} v${versao}`);
    }

    return template;
  }

  listAtivos(): TemplateCalculo[] {
    return Array.from(this.templates.values()).filter(t => t.isAtivo());
  }

  private buildKey(codigo: string, versao: string): string {
    return `${codigo}::${versao}`;
  }
}