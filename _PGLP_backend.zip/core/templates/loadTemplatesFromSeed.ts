// /core/templates/loadTemplatesFromSeed.ts

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

import { TemplateCalculo } from './TemplateCalculo';
import { TemplateRepository } from './TemplateRepository';

export function loadTemplatesFromSeed(
  repository: TemplateRepository,
  seedPath: string
): void {
  const absolutePath = path.resolve(seedPath);
  const raw = fs.readFileSync(absolutePath, 'utf-8');
  const data = JSON.parse(raw);

  data.forEach((tpl: any) => {
    const hash = crypto
      .createHash('sha256')
      .update(
        tpl.codigo +
          tpl.versao +
          tpl.formula_simbolica +
          JSON.stringify(tpl.formula_desenhada)
      )
      .digest('hex');

    const template = new TemplateCalculo({
      idTemplate: tpl.id_template,
      codigo: tpl.codigo,
      nome: tpl.nome,
      descricao: tpl.descricao,

      norma: tpl.norma,
      parteNorma: tpl.parte_norma,

      formulaSimbolica: tpl.formula_simbolica,
      formulaDesenhada: tpl.formula_desenhada,
      variaveis: tpl.variaveis,

      legendaPadrao: tpl.legenda_padrao,
      memoriaPadrao: tpl.memoria_padrao,

      usoPermitido: tpl.uso_permitido,
      financeiro: tpl.financeiro,

      versao: tpl.versao,
      hashTemplate: hash,
      status: tpl.status
    });

    repository.add(template);
  });
}