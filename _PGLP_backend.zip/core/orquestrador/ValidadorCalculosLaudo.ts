// /core/orquestrador/ValidadorCalculosLaudo.ts

export interface CalculoAuditavelLaudo {
  template: {
    codigo: string;
    versao: string;
    norma: string;
    hash: string;
  };
  valorFinal: number;
  memoriaCalculo: string[];
}

export class ValidadorCalculosLaudo {

  static validar(calculos: CalculoAuditavelLaudo[]): void {

    if (!calculos || calculos.length === 0) {
      throw new Error(
        'Laudo não possui cálculos auditáveis. Assinatura bloqueada.'
      );
    }

    calculos.forEach((calculo, index) => {

      // 1️⃣ Template obrigatório
      if (!calculo.template?.codigo || !calculo.template?.versao) {
        throw new Error(
          `Cálculo ${index + 1}: ausência de template normativo.`
        );
      }

      // 2️⃣ Norma obrigatória
      if (!calculo.template.norma.includes('NBR 14653')) {
        throw new Error(
          `Cálculo ${index + 1}: norma incompatível (${calculo.template.norma}).`
        );
      }

      // 3️⃣ Hash obrigatório
      if (!calculo.template.hash) {
        throw new Error(
          `Cálculo ${index + 1}: template sem hash (violação de governança).`
        );
      }

      // 4️⃣ Memória de cálculo obrigatória
      if (!calculo.memoriaCalculo || calculo.memoriaCalculo.length === 0) {
        throw new Error(
          `Cálculo ${index + 1}: memória de cálculo ausente.`
        );
      }

      // 5️⃣ Valor final válido
      if (calculo.valorFinal === null || calculo.valorFinal === undefined) {
        throw new Error(
          `Cálculo ${index + 1}: valor final inexistente.`
        );
      }
    });
  }
}