// /core/orquestrador/OrquestradorLaudo.ts

import { ValidadorCalculosLaudo, CalculoAuditavelLaudo } 
  from './ValidadorCalculosLaudo';

export class OrquestradorLaudo {

  static antesDeAssinarLaudo(
    calculos: CalculoAuditavelLaudo[]
  ): void {

    // 🔒 Validação normativa obrigatória
    ValidadorCalculosLaudo.validar(calculos);

    // Se chegou aqui, o laudo está apto
  }

}