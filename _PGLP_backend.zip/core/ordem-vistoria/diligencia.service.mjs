/**
=========================================================
PROJETO: PGLP – Plataforma de Gestão de Laudos Periciais
MÓDULO: Ordem de Vistoria / Diligência
ARQUIVO: diligencia.service.mjs
VERSÃO: 1.0.0
DATA: 24/03/2026

DESCRIÇÃO:
Orquestra o fluxo completo de diligência.

RESPONSABILIDADE:
Integrar validação, normalização, persistência e geração de certidão.

STATUS: ATIVO
=========================================================
*/

import { registrarTentativa as registrar } from "./tentativas/diligencia.tentativas.mjs";
import { listarPorOrdem } from "./repository/diligencia.repository.mjs";

export function registrarTentativa(ordemId, payload) {
  return registrar(ordemId, payload);
}

export function listarDiligencias(ordemId) {
  return listarPorOrdem(ordemId);
}