/**
=========================================================
PROJETO: PGLP – Plataforma de Gestão de Laudos Periciais
MÓDULO: Ordem de Vistoria / Diligência
ARQUIVO: diligencia.status.mjs
VERSÃO: 1.0.0
DATA: 24/03/2026

DESCRIÇÃO:
Camada de persistência da diligência.

RESPONSABILIDADE:
Salvar e recuperar dados de diligência.

STATUS: ATIVO
=========================================================
*/
export const STATUS_TENTATIVA = {
  REALIZADA: "REALIZADA",
  AUSENTE: "AUSENTE",
  IMPOSSIVEL: "IMPOSSIVEL"
};