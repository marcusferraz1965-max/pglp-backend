/**
=========================================================
PROJETO: PGLP – Plataforma de Gestão de Laudos Periciais
MÓDULO: Ordem de Vistoria / Diligência
ARQUIVO: diligencia.certidoes.mjs
VERSÃO: 1.0.0
DATA: 24/03/2026

DESCRIÇÃO:
Camada de persistência da diligência.

RESPONSABILIDADE:
Salvar e recuperar dados de diligência.

STATUS: ATIVO
=========================================================
*/
export function gerarCertidao(tentativa) {
  const base = {
    data: tentativa.dataHora,
    responsavel: tentativa.responsavel || "Perito responsável"
  };

  if (tentativa.resultado === "AUSENTE") {
    return {
      tipo: "AUSENCIA",
      texto: `Certifico que na data ${base.data} não foi possível realizar a vistoria em razão da ausência de responsável no local.`
    };
  }

  if (tentativa.resultado === "IMPOSSIVEL") {
    return {
      tipo: "IMPOSSIBILIDADE",
      texto: `Certifico que na data ${base.data} foi impossível realizar a vistoria por impedimentos constatados.`
    };
  }

  if (tentativa.resultado === "REALIZADA") {
    return {
      tipo: "REALIZADA",
      texto: `Certifico que na data ${base.data} a vistoria foi realizada com sucesso.`
    };
  }
}