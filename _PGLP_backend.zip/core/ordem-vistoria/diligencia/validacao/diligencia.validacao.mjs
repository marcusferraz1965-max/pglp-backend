/**
=========================================================
PROJETO: PGLP – Plataforma de Gestão de Laudos Periciais
MÓDULO: Ordem de Vistoria / Diligência
ARQUIVO: diligencia.validacao.mjs
VERSÃO: 1.0.0
DATA: 24/03/2026

DESCRIÇÃO:
Camada de persistência da diligência.

RESPONSABILIDADE:
Salvar e recuperar dados de diligência.

STATUS: ATIVO
=========================================================
*/
export function validarTentativa(payload) {
  if (!payload.resultado) {
    throw new Error("Resultado da tentativa é obrigatório");
  }
}