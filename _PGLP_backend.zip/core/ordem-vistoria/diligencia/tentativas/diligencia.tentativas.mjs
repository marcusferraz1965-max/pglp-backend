/**
=========================================================
PROJETO: PGLP – Plataforma de Gestão de Laudos Periciais
MÓDULO: Ordem de Vistoria / Diligência
ARQUIVO: diligencia.tentativas.mjs
VERSÃO: 1.0.0
DATA: 24/03/2026

DESCRIÇÃO:
Gerencia o registro de tentativas de diligência.

RESPONSABILIDADE:
Receber dados da tentativa, validar, normalizar e persistir,
além de acionar geração automática de certidão.

REGRAS:
✔ Toda tentativa deve ser validada
✔ Deve gerar certidão automaticamente
✔ Não contém lógica de API

STATUS: ATIVO
=========================================================
*/

import { validarTentativa } from "../validacao/diligencia.validacao.mjs";
import { normalizarTentativa } from "../normalizacao/diligencia.normalizacao.mjs";
import { salvarDiligencia } from "../repository/diligencia.repository.mjs";
import { gerarCertidao } from "../certidoes/diligencia.certidoes.mjs";

export function registrarTentativa(ordemId, payload) {
  // 1. Validação
  validarTentativa(payload);

  // 2. Normalização
  const tentativa = normalizarTentativa(ordemId, payload);

  // 3. Persistência da tentativa
  salvarDiligencia(tentativa);

  // 4. Geração automática de certidão
  const certidao = gerarCertidao(tentativa);

  if (certidao) {
    salvarDiligencia(certidao);
  }

  return tentativa;
}