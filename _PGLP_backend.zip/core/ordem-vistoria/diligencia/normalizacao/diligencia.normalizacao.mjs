/**
=========================================================
PROJETO: PGLP – Plataforma de Gestão de Laudos Periciais
MÓDULO: Ordem de Vistoria / Diligência
ARQUIVO: diligencia.normalizacao.mjs
VERSÃO: 1.0.0
DATA: 24/03/2026

DESCRIÇÃO:
Responsável por normalizar os dados de entrada da diligência.

RESPONSABILIDADE:
Padronizar estrutura dos dados antes da persistência.

REGRAS:
✔ Gerar ID único
✔ Garantir data/hora padrão ISO
✔ Padronizar campos de descrição
✔ Não validar regras de negócio

STATUS: ATIVO
=========================================================
*/

export function normalizarTentativa(ordemId, payload) {
  return {
    id: gerarId(),
    ordemId,
    tipo: "TENTATIVA",
    dataHora: new Date().toISOString(),

    resultado: payload.resultado,

    descricao: (payload.observacao || "").trim(),

    // Preparado para evolução futura
    responsavel: payload.responsavel || null,
    origem: "SISTEMA"
  };
}

// Gerador simples (depois pode virar UUID real)
function gerarId() {
  return Date.now() + Math.floor(Math.random() * 1000);
}