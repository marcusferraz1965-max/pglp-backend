/**
=========================================================
PROJETO: PGLP – Plataforma de Gestão de Laudos Periciais
MÓDULO: Ordem de Vistoria / Diligência
ARQUIVO: diligencia.repository.mjs
VERSÃO: 1.0.0
DATA: 24/03/2026

DESCRIÇÃO:
Camada de persistência da diligência.

RESPONSABILIDADE:
Salvar e recuperar dados de diligência.

STATUS: ATIVO
=========================================================
*/

const DB = {
  diligencias: []
};

export function salvarDiligencia(dado) {
  DB.diligencias.push(dado);
  return dado;
}

export function listarPorOrdem(ordemId) {
  return DB.diligencias.filter(d => d.ordemId === ordemId);
}