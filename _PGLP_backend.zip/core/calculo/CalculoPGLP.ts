// /core/calculo/CalculoPGLP.ts

import { TemplateRepository } from '../templates/TemplateRepository';
import { TemplateCalculo } from '../templates/TemplateCalculo';

export interface ResultadoCalculoAuditavel {
  template: {
    codigo: string;
    versao: string;
    norma: string;
    parteNorma?: string;
    hash: string;
  };
  valorFinal: number;
  memoriaCalculo: string[];
  executadoEm: Date;
}

export class CalculoPGLP {
  constructor(private readonly templateRepo: TemplateRepository) {}

  executar(
    codigoTemplate: string,
    versao: string,
    valores: Record<string, number>
  ): ResultadoCalculoAuditavel {
    const template = this.templateRepo.get(codigoTemplate, versao);

    this.validarVariaveis(template, valores);

    const { valorFinal, memoria } = this.executarTemplate(template, valores);

    return {
      template: {
        codigo: template.codigo,
        versao: template.versao,
        norma: template.norma,
        parteNorma: template.parteNorma,
        hash: template.hashTemplate
      },
      valorFinal,
      memoriaCalculo: memoria,
      executadoEm: new Date()
    };
  }

  // -------------------------
  // Execução por tipo
  // -------------------------

  private executarTemplate(
    template: TemplateCalculo,
    valores: Record<string, number>
  ): { valorFinal: number; memoria: string[] } {
    switch (template.codigo) {
      case 'VU_M2':
        return this.execValorUnitario(valores);

      case 'HOMOGENEIZACAO':
        return this.execHomogeneizacao(valores);

      case 'VALOR_MEDIO':
        return this.execValorMedio(valores);

      case 'DEPRECIACAO':
        return this.execDepreciacao(valores);

      case 'VALOR_FINAL':
        return this.execValorFinal(valores);

      default:
        throw new Error(`Template não suportado: ${template.codigo}`);
    }
  }

  // -------------------------
  // Implementações reais
  // -------------------------

  private execValorUnitario(valores: Record<string, number>) {
    const { V_ref, A } = valores;

    const resultado = V_ref / A;

    return {
      valorFinal: resultado,
      memoria: [
        `V_ref = ${V_ref}`,
        `A = ${A}`,
        `VU = ${V_ref} ÷ ${A} = ${resultado}`
      ]
    };
  }

  private execHomogeneizacao(valores: Record<string, number>) {
    let resultado = valores.V_base;
    const memoria: string[] = [`V_base = ${valores.V_base}`];

    Object.keys(valores).forEach(k => {
      if (k.startsWith('F_')) {
        resultado *= valores[k];
        memoria.push(`${k} = ${valores[k]}`);
      }
    });

    memoria.push(`V_hom = ${resultado}`);

    return { valorFinal: resultado, memoria };
  }

  private execValorMedio(valores: Record<string, number>) {
    const { soma, n } = valores;

    const resultado = soma / n;

    return {
      valorFinal: resultado,
      memoria: [
        `Soma dos valores = ${soma}`,
        `n = ${n}`,
        `V_médio = ${soma} ÷ ${n} = ${resultado}`
      ]
    };
  }

  private execDepreciacao(valores: Record<string, number>) {
    const { V_base, d } = valores;

    const resultado = V_base * d;

    return {
      valorFinal: resultado,
      memoria: [
        `V_base = ${V_base}`,
        `d = ${d}`,
        `Depreciação = ${V_base} × ${d} = ${resultado}`
      ]
    };
  }

  private execValorFinal(valores: Record<string, number>) {
    const { V_base, D } = valores;

    const resultado = V_base - D;

    return {
      valorFinal: resultado,
      memoria: [
        `V_base = ${V_base}`,
        `D = ${D}`,
        `V_final = ${V_base} − ${D} = ${resultado}`
      ]
    };
  }

  // -------------------------
  // Validações normativas
  // -------------------------

  private validarVariaveis(
    template: TemplateCalculo,
    valores: Record<string, number>
  ) {
    const varsTemplate = Object.keys(template.variaveis);

    varsTemplate.forEach(v => {
      if (!(v in valores)) {
        throw new Error(
          `Variável obrigatória ausente (${v}) para template ${template.codigo}`
        );
      }
    });
  }
}