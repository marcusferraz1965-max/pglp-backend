// /core/calculo/CalculoRepositoryMemory.ts

import { CalculoRepository } from './CalculoRepository';
import { CalculoPersistido } from './CalculoPersistido';

export class CalculoRepositoryMemory implements CalculoRepository {
  private calculos: CalculoPersistido[] = [];

  async salvar(calculo: CalculoPersistido): Promise<void> {
    this.calculos.push(calculo);
  }

  async listarPorLaudo(laudoId: string): Promise<CalculoPersistido[]> {
    return this.calculos.filter(c => c.laudoId === laudoId);
  }
}