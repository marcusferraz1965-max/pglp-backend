// /core/calculo/CalculoRepository.ts

import { CalculoPersistido } from './CalculoPersistido';

export interface CalculoRepository {
  salvar(calculo: CalculoPersistido): Promise<void>;
  listarPorLaudo(laudoId: string): Promise<CalculoPersistido[]>;
}