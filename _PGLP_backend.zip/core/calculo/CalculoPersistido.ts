// /core/calculo/CalculoPersistido.ts

export class CalculoPersistido {
  readonly idCalculo: string;
  readonly laudoId: string;

  readonly templateCodigo: string;
  readonly templateVersao: string;
  readonly templateHash: string;
  readonly norma: string;
  readonly parteNorma?: string;

  readonly valorFinal: number;
  readonly memoriaCalculo: string[];

  readonly criadoEm: Date;

  constructor(props: CalculoPersistido) {
    Object.assign(this, props);
  }
}